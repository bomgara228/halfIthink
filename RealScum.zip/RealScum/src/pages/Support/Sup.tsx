import style from "./Sup.module.css"

const Support = () => {    
    return (
        <div className={style.to_the_centr}>
            <h2  className={style.QF}>Поддержка Scum</h2>
            <h3  className={style.QF}>С чем вам нужно помочь?</h3>
            <div className={style.fakeQuest} onClick={() => {
                console.log('DF')
                window.close()
            }}><h2>Игры, программы и т.д.</h2></div>
            <div className={style.fakeQuest} onClick={() => window.close()}><h2>Покупки</h2></div>
            <div className={style.fakeQuest} onClick={() => window.close()}><h2>Мой аккаунт</h2></div>
            <div className={style.fakeQuest} onClick={() => window.close()}><h2>Обмен, подарки, торгова площадка и очки Scum</h2></div>
            <div className={style.fakeQuest} onClick={() => window.close()}><h2>Клиент Scum</h2></div>
            <div className={style.fakeQuest} onClick={() => window.close()}><h2>Сообщество Scum</h2></div>
            <div className={style.fakeQuest} onClick={() => window.close()}><h2>Устройства Scum</h2></div>
        </div>
    )
}
export default Support